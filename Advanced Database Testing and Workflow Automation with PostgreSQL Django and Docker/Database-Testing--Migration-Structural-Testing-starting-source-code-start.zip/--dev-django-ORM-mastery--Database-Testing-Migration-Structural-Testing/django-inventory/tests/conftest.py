import pytest
from factories import CategoryFactory
from fixtures import django_db_setup  # noqa F401
from pytest_factoryboy import register

register(CategoryFactory)

CUSTOM_DATABASE_ALIAS = "inventory_db"


@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(items):
    for item in items:
        marker = item.get_closest_marker("django_db")
        if marker:
            databases = marker.kwargs.get("database", ["default"])
            if CUSTOM_DATABASE_ALIAS not in databases:
                databases.append(CUSTOM_DATABASE_ALIAS)
            marker.kwargs["databases"] = databases

    for item in items:
        if "model" in item.name:
            item.add_marker(pytest.mark.model)
        if "structure" in item.name:
            item.add_marker(pytest.mark.model_structure)
        if "model_migration" in item.name:
            item.add_marker(pytest.mark.model_migration)
