import pytest
from django.db import IntegrityError, connection, transaction
from inventory.models import Category

###############################################
# """
# Structural Testing:
# Table and Column Validation
# """
###############################################

# """
# - [ ] Confirm the presence of required table within the database.
# """

"""
## Table and Column Validation
"""

# """
# - [ ] Confirm the presence of required table within the database schema.
# """


@pytest.mark.django_db
def test_model_migration_structure_table_exists():
    try:
        from inventory.models import Category
    except ImportError:
        assert False
    else:
        table_names = connection.introspection.table_names()
        assert Category._meta.db_table in table_names


# """
# - [ ] Validate the existence of expected columns in each table, ensuring correct data types.
# """


@pytest.mark.parametrize(
    "model, field_name, expected_type",
    [
        (Category, "id", "bigint"),
        (Category, "name", "character varying"),
        (Category, "slug", "character varying"),
        (Category, "is_active", "boolean"),
        (Category, "level", "integer"),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_column_data_types(model, field_name, expected_type):
    with connection.cursor() as cursor:
        cursor.execute(
            f"""
            SELECT data_type
            FROM information_schema.columns
            WHERE table_name = '{model._meta.db_table}'
            AND column_name = '{field_name}'
            """
        )
        result = cursor.fetchone()
        column_data_type = result[0]

        # Assert that a result was found
        assert result is not None, f"Column '{field_name}' not found in table"

        assert (
            column_data_type.lower() == expected_type.lower()
        ), f"Field '{field_name}' in '{model.__name__}' is not type {expected_type}"


# """
# - [ ] Confirm expected field count
# """


@pytest.mark.parametrize(
    "model, expected_field_count",
    [
        (
            Category,
            6,
        ),  # Replace with the expected number of fields in the SeasonalEvent model
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_field_count(model, expected_field_count):
    table_name = model._meta.db_table

    query = f"""
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_name = '{table_name}'
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

        actual_field_count = result[0]

        assert actual_field_count == expected_field_count, (
            f"{model.__name__} model has {actual_field_count} fields in the database, "
            f"expected {expected_field_count}"
        )


# """
# - [ ] Ensure that column relationships are correctly defined.
# """


@pytest.mark.parametrize(
    "model, field_name, related_model, on_delete_behavior, allow_null",
    [
        (Category, "parent_id", Category, "NO ACTION", "YES"),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_relationship(
    model,
    field_name,
    related_model,
    on_delete_behavior,
    allow_null,
):
    table_name = model._meta.db_table

    query = f"""
    SELECT ccu.table_name AS foreign_table_name,
           ccu.column_name AS foreign_column_name,
           rc.update_rule,
           rc.delete_rule,
           c.is_nullable
    FROM information_schema.table_constraints AS tc
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
    JOIN information_schema.referential_constraints AS rc
      ON rc.constraint_name = tc.constraint_name
    JOIN information_schema.columns AS c
      ON c.column_name = kcu.column_name AND c.table_name = kcu.table_name
    WHERE tc.table_name = '{table_name}'
      AND kcu.column_name = '{field_name}';
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    foreign_table_name, foreign_column_name, update_rule, delete_rule, is_nullable = (
        result
    )

    # Assert foreign table name matches related model's database table name
    assert foreign_table_name == related_model._meta.db_table

    # Assert foreign column name matches related model's primary key column name
    assert (
        foreign_column_name == related_model._meta.pk.column
    ), f"Foreign column name mismatch. Expected '{related_model._meta.pk.column}', got '{foreign_column_name}'."

    # Assert update rule matches expected on delete behavior
    assert (
        update_rule.upper() == on_delete_behavior.upper()
    ), f"Update rule mismatch. Expected '{on_delete_behavior.upper()}', got '{update_rule.upper()}'."

    # Assert nullable attribute matches expected allow null value
    assert (
        is_nullable == allow_null
    ), f"Nullable attribute mismatch. Expected '{allow_null}', got '{is_nullable}'."


# """
# - [ ] Verify nullable or not nullable fields
# """


@pytest.mark.parametrize(
    "model, field_name, expected_nullable",
    [
        (Category, "id", False),
        (Category, "name", False),
        (Category, "slug", False),
        (Category, "is_active", False),
        (Category, "level", False),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_nullable_constraints(
    model, field_name, expected_nullable
):
    table_name = model._meta.db_table

    query = f"""
    SELECT is_nullable
    FROM information_schema.columns
    WHERE table_name = '{table_name}'
    AND column_name = '{field_name}'
    """
    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    actual_nullable = result[0] == "YES"

    assert actual_nullable == expected_nullable, (
        f"Field '{field_name}' has unexpected nullable constraint. "
        f"Expected: {expected_nullable}, Actual: {actual_nullable}"
    )


# """
# - [ ] Verify the correctness of default values for relevant columns.
# """


@pytest.mark.parametrize(
    "model, field_name, expected_default_value",
    [
        (Category, "is_active", False),
        (Category, "level", 0),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_default_values(
    model, field_name, expected_default_value
):
    table_name = model._meta.db_table

    query = f"""
    SELECT column_default
    FROM information_schema.columns
    WHERE table_name = '{table_name}'
    AND column_name = '{field_name}'
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    actual_default_value = result[0]

    actual_default_value_str = str(actual_default_value).lower()
    expected_default_value_str = str(expected_default_value).lower()

    assert actual_default_value_str == expected_default_value_str


# """
# - [ ] Ensure that column lengths align with defined requirements.
# """


@pytest.mark.parametrize(
    "model, field_name, expected_length",
    [
        (Category, "name", 100),
        (Category, "slug", 120),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_column_lengths(model, field_name, expected_length):
    table_name = model._meta.db_table

    query = f"""
    SELECT character_maximum_length
    FROM information_schema.columns
    WHERE table_name = '{table_name}'
    AND column_name = '{field_name}'
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    actual_length = result[0]

    assert actual_length == expected_length, (
        f"Field '{field_name}' has unexpected max length. "
        f"Expected: {expected_length}, Actual: {actual_length}"
    )


# """
# - [ ] Validate the enforcement of unique constraints for columns requiring unique values.
# """


@pytest.mark.parametrize(
    "model, field_name, is_unique",
    [
        (Category, "id", True),
        (Category, "name", False),
        (Category, "slug", True),
        (Category, "is_active", False),
        (Category, "level", False),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_unique_fields(model, field_name, is_unique):
    table_name = model._meta.db_table

    query = f"""
        SELECT COUNT(*)
        FROM pg_constraint AS con
        JOIN pg_class AS tbl ON con.conrelid = tbl.oid
        JOIN pg_attribute AS attr ON attr.attnum = ANY(con.conkey) AND attr.attrelid = tbl.oid
        WHERE tbl.relname = '{table_name}'
        AND attr.attname = '{field_name}'
        AND (con.contype = 'u' OR con.contype = 'p')
        AND array_length(con.conkey, 1) = 1;
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    if is_unique:
        assert result[0] > 0
    else:
        assert result[0] == 0


###############################################
# """
# Structural Testing:
# Custom Validation
# """
###############################################


# """
# - [ ] Test Enforcement of Empty String Constraint
# """


@pytest.mark.django_db
def test_model_migration_structure_empty_string_constraint(category_factory):
    # Attempt to create and save an instance with an empty name
    with pytest.raises(IntegrityError):
        with transaction.atomic():
            category_factory.create(name="")


# """
# - [ ] Test Enforcement of Slug Format Constraint
# """


@pytest.mark.parametrize(
    "model_class, slug_value, should_raise_error",
    [
        (
            Category,
            "valid-slug-123",
            False,
        ),  # Valid slug for Category model, should not raise an error
        (
            Category,
            "valid_slug_456",
            False,
        ),  # Another valid slug, should not raise an error
        (
            Category,
            "Invalid Slug!",
            True,
        ),  # Invalid slug (contains spaces and special characters), should raise an IntegrityError
        (
            Category,
            "anotherInvalidSlug@",
            True,
        ),  # Invalid slug (contains special characters), should raise an IntegrityError
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_slug_format_constraint(
    category_factory, model_class, slug_value, should_raise_error
):
    if should_raise_error:
        with pytest.raises(IntegrityError):
            category_factory.create(slug=slug_value)
    else:
        valid_instance = category_factory.create(slug=slug_value)
        assert model_class.objects.filter(
            id=valid_instance.id
        ).exists(), "Valid slug record was not found in the database"


# """
# - [ ] Test Enforcement of Level Boundaries Constraint
# """


@pytest.mark.parametrize(
    "field, num_field_value, should_raise_error",
    [
        ("level", -1, True),  # Below lower bound, should raise an IntegrityError
        ("level", 0, False),  # On lower bound, should not raise an error
        ("level", 5, False),  # Within the range, should not raise an error
        ("level", 10, False),  # On upper bound, should not raise an error
        ("level", 11, True),  # Above upper bound, should raise an IntegrityError
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_level_boundaries_constraint(
    category_factory, field, num_field_value, should_raise_error
):
    if should_raise_error:
        with pytest.raises(IntegrityError):
            category_factory.create(**{field: num_field_value})

    else:
        try:
            instance = category_factory.create(**{field: num_field_value})

            assert Category.objects.filter(id=instance.id).exists()

        except IntegrityError:
            pytest.fail("IntegrityError was raised unexpectedly")


###############################################
# """
# Structural Testing:
# Procedure Function Testing
# """
###############################################

# """
# - [ ] Verify stored procedures and functions.
# """


@pytest.mark.parametrize("procedure_name", ["lowercase_name_trigger"])
@pytest.mark.django_db
def test_model_migration_structure_verify_procedure_functions(procedure_name):
    query = f"""
    SELECT routine_name
    FROM information_schema.routines
    WHERE routine_name = '{procedure_name}'
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    assert (
        result is not None
    ), f"Stored procedure or function '{procedure_name}' not found in the database"


# """
# - [ ] Test trigger behaviour lowercase_name_trigger
# """


@pytest.mark.parametrize(
    "model, test_name, expected_name",
    [
        (Category, "UPPERCASE NAME", "uppercase name"),
        (Category, "Another Test", "another test"),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_lowercase_name_trigger(
    model, test_name, expected_name
):
    instance = model.objects.create(name=test_name)

    stored_instance = model.objects.get(id=instance.id)

    assert (
        stored_instance.name == expected_name
    ), f"Expected name '{expected_name}', but got '{stored_instance.name}'"


###############################################
# """
# Structural Testing:
# Schema Testing
# """
###############################################

# """
# - [ ] Verify the presence of a specific schema in the database
# """


@pytest.mark.parametrize(
    "schema_name",
    ["inventory_schema", "inventory_management_schema"],
)
@pytest.mark.django_db
def test_model_migration_structure_schema_existance(schema_name):
    query = f"""
    SELECT schema_name
    FROM information_schema.schemata
    WHERE schema_name = '{schema_name}'
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    assert result is not None, f"Schema '{schema_name}' not found in the database"


# """
# - [ ] Validate that table is part of the correct schema
# """


@pytest.mark.parametrize(
    "schema_name, table_name",
    [
        ("inventory_schema", "inventory_category"),
        ("inventory_management_schema", "django_migrations"),
    ],
)
@pytest.mark.django_db
def test_model_migration_structure_table_in_correct_schema(schema_name, table_name):
    query = f"""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = '{schema_name}'
    AND table_name = '{table_name}'
    """

    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()

    assert (
        result is not None
    ), f"Table '{table_name}' not found in schema '{schema_name}'"
