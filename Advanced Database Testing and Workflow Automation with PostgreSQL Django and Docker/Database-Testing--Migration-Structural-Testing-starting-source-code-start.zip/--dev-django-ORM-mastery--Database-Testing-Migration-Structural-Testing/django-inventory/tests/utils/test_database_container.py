import os
import time

import docker
import docker.errors


def start_database_container():
    client = docker.from_env(timeout=5)
    container_name = "test-db"
    script_dir = os.path.abspath("../postgres/scripts")

    try:
        # Check if the container already exists
        existing_container = client.containers.get(container_name)
        print(f"Container '{container_name}' exists.")
        # Stop and remove the existing container
        existing_container.stop()
        existing_container.remove()
        print(f"Container '{container_name}' stopped and removed.")
    except docker.errors.NotFound:
        # If the container does not exist, print a message
        print(f"Container '{container_name}' does not exist.")

    # Define health check configuration as a dictionary
    healthcheck_config = {
        "test": [
            "CMD-SHELL",
            "pg_isready -U postgres",
        ],  # Command to check if PostgreSQL is ready
        "interval": 1000000000,  # Interval between health checks (1 second in nanoseconds)
        "timeout": 5000000000,  # Timeout for a single health check (1 second in nanoseconds)
        "retries": 5,  # Number of retries before considering the container unhealthy
        "start_period": 2000000000,  # Start period before health checks start (2 seconds in nanoseconds)
    }

    # Define container configuration
    container_config = {
        "image": "postgres:16.3-alpine3.20",  # Docker image to use
        "name": container_name,  # Name of the container
        "detach": True,  # Run the container in detached mode
        "ports": {
            "5432": "5433"  # Map port 5432 in the container to port 5433 on the host
        },
        "environment": {
            "POSTGRES_USER": "postgres",  # Set PostgreSQL user
            "POSTGRES_PASSWORD": "postgres",  # Set PostgreSQL password
        },
        "volumes": [f"{script_dir}:/docker-entrypoint-initdb.d"],
        "healthcheck": healthcheck_config,
        "network_mode": "django-ecommerce_dev-network"
    }

    try:
        container = client.containers.run(**container_config)
        print(f"Container '{container_name}' has started.")
        # Wait for PostgreSQL to be ready
        wait_for_postgres_healthcheck(container)
        print("Postgres in ready")
    except docker.errors.APIError as e:
        print(f"Failed to start container: {e}")
        raise

    return container


def wait_for_postgres_healthcheck(container, timeout=60):
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            container.reload()
            if container.status == "running":
                if check_postgres_health(container):
                    print("Health Check Passed")
                    return True
            time.sleep(2)
        except Exception as e:
            print(f"Error checking container status: {e}")


def check_postgres_health(container):
    """
    Checks if the PostgreSQL container is healthy.
    Returns True if healthy, False otherwise.
    """
    health = container.attrs.get("State", {}).get("Health", {})
    return health.get("Status") == "healthy"
