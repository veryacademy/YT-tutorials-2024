import factory
from faker import Faker
from inventory.models import Category

fake = Faker()


class CategoryFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Category

    name = factory.LazyAttribute(lambda _: fake.unique.word())
    slug = factory.LazyAttribute(lambda _: fake.unique.word())
    is_active = factory.Faker("boolean")
    level = factory.Faker("random_int", min=0, max=10)
    parent_id = None
