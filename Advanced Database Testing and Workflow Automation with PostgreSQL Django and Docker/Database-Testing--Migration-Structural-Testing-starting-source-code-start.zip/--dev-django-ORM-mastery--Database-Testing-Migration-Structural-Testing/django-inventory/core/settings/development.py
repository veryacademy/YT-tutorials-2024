import os

from .core import *

DATABASES = {
    "default": {},
    "django_db": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    },
    "inventory_db": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("DB_NAME"),
        "USER": os.getenv("DB_USER"),
        "PASSWORD": os.getenv("DB_PASSWORD"),
        "HOST": os.getenv("DB_HOST"),
        "PORT": os.getenv("DB_PORT"),
        # "OPTIONS": {
        #     'options' : '-c search_path=inventory_schema, inventory_management_schema'
        # }
    },
}
