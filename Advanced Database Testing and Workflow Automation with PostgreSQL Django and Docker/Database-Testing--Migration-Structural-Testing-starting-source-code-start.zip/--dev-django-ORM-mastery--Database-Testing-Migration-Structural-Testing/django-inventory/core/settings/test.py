import os

from .core import *

DATABASES = {
    "inventory_db": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("TEST_DB_NAME"),
        "USER": os.getenv("TEST_DB_USER"),
        "PASSWORD": os.getenv("TEST_DB_PASSWORD"),
        "HOST": os.getenv("TEST_DB_HOST"),
        "PORT": os.getenv("TEST_DB_PORT"),
        # "OPTIONS": {
        #     'options' : '-c search_path=inventory_schema, inventory_management_schema'
        # }
    },
}

DATABASES["default"] = DATABASES["inventory_db"]
