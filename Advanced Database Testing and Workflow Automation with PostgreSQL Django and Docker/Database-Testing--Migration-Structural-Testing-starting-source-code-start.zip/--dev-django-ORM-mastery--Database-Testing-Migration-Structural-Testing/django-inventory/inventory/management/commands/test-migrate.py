from django.core.management.base import CommandError
from django.core.management.commands.migrate import Command as MigrateCommand


class Command(MigrateCommand):
    help = "Run migrations with app name"

    def handle(self, *args, **options):
        app_label = options.get("app_label")
        if not app_label:
            raise CommandError("No app has been specified")

        super().handle(*args, **options)
