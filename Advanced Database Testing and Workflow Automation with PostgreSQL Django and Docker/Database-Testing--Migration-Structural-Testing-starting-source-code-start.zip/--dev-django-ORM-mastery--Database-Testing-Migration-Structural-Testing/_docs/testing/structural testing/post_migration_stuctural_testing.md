# 1. Structural Testing

## Table and Column Validation

- [ ] Confirm the presence of table within the database schema.

- [ ] Validate the existence of expected columns in each table, ensuring correct data types.

- [ ] Verify expected field count

- [ ] Ensure that column relationships are correctly defined.

- [ ] Verify nullable or not nullable fields

- [ ] Verify the correctness of default values for relevant columns.

- [ ] Ensure that column lengths align with defined requirements.

- [ ] Validate the enforcement of unique constraints for columns requiring unique values.

- [ ] Test Enforcement of Empty String Constraint

- [ ] Test Enforcement of Slug Format Constraint

- [ ] Test Enforcement of Level Boundaries Constraint

- [ ] Validate the enforcement of composite unique constraints on specified columns.