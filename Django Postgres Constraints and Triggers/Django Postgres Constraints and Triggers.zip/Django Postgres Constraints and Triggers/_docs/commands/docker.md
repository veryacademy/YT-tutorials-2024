# Docker Commands

This guide outlines various docker commands.

- **Build and start docker**
    ```
    docker compose up
    ```
